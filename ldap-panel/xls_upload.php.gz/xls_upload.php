<?php

include 'config.php';

$projecturl = get_project_url(); 						// "192.168.1.202"
	$ldapconnectaddress = get_ldap_connect_address();		// "127.0.0.1"
	$ldapconnectport = get_ldap_connect_port();				// 389
	$adminbindrdn = get_admin_bind_rdn();					// cn=admin,dc=elenoon,dc=ir
	$adminbindpass = get_admin_bind_pass();					// ahmad@91
	$mainserverrdn = get_main_server_rdn();					// dc=elenoon,dc=ir
	$customadmindn = get_custom_admin_dn();					// cn=customadmin
	$customadminrdn = get_custom_admin_rdn();				// cn=customadmin,dc=elenoon,dc=ir
	$customadminusername = get_custom_admin_username();		// customadmin
	$customadminpass = get_custom_admin_pass();				// abas?1371
	$bindadmindn = get_bind_admin_dn();						// cn=admin
	$bindadminrdn = get_bind_admin_rdn();					// cn=admin,dc=elenoon,dc=ir
	$indexpagelocation = get_index_page_location();			// /ldappanel/index.php
	$panelpagelocation = get_panel_page_location();			// /ldappanel/panel.php 
	$logoutpagelocation = get_logout_page_location();		// /ldappanel/logout.php
	$node1rdn = get_node1_rdn();							// ou=node1,dc=elenoon,dc=ir
	$node1usablerdn = get_node1_usable_rdn();				//,ou=node1,dc=elenoon,dc=ir
	$zarafauserserver = get_zarafauserserver();				// 192.168.0.22
	$oustar = get_ou_star(); 								// ou=*


header('Content-type: application/json');

$output_dir = "uploadxls/";
$externaloufromui = $_POST['myou'];
//echo $externaloufromui;

// error_reporting(E_ALL);
// set_time_limit(0);

date_default_timezone_set('Europe/London');
set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

function create_user_array($name,$mobile,$email,$pass){

								global $zarafauserserver;
								global $node1usablerdn;
								global $externaloufromui;

								$atdomain = "@fci.co.ir";

								$gidnumber = 100009;

								$return_array = Array();
								global $externaloufromui;

								$dn = "uid=" . $mobile . $atdomain . "," . $externaloufromui . ",ou=node1,dc=elenoon,dc=ir";

								$externalou = "uid=" . $mobile . $atdomain . "," . $externaloufromui ;

								$homedirectory = "/home/98" . $mobile . $gidnumber;

								$entry_array = Array ( "cn" => $name  , "gidnumber" =>  $gidnumber , "homedirectory" => $homedirectory , "mail" => $email , "mobile" => $mobile ,"objectclass" => Array ("0" => "posixAccount" , "1" => "top" , "2" => "zarafa-user" , "3" => "inetOrgPerson")  , "sn" => $mobile  , "uid"  => $email  , "uidnumber" => $gidnumber , "userpassword" =>  $pass , "zarafaaccount" =>  1 , "zarafaadmin" =>  0 , "zarafaalertsms" =>  1 , "zarafaaliases" =>  $mobile.$atdomain , "zarafaconfirm" =>  1 , "zarafaenabledfeatures" => Array (  "0" => "imap" , "1" => "pop3" ) , "zarafahidden" =>  1 , "zarafaquotahard" =>  1900 , "zarafaquotaoverride" => 1 , "zarafaquotasoft" => 1800 , "zarafaquotawarn" =>  1700 , "zarafasharedstoreonly" => 0 ,  "zarafauserserver" =>  $zarafauserserver) ;

								$return_array[0] = $dn;
								$return_array[1] = $entry_array;

								return $return_array;

					};

function user_add($ldap_dn,$ldap_entry_array){
		global $ldapconnectaddress;
		global $ldapconnectport;
		global $adminbindrdn;
		global $adminbindpass;
						$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );
						ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
			                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        			ldap_set_option($ds, LDAP_OPT_REFERRALS,0);

						if ($ds) {

							$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);
							if ($r) {
							 
								$sr=ldap_add($ds , $ldap_dn , $ldap_entry_array);
								if ($sr) {

									  return true;

								 		  }else{return false;};
								 	}else{return false;};
								 }else{return false;};

					};
function get_response_success($inout_respons_success_array){

						$respons_success_array = Array("0"=>Array("responsestatustext"=>"با تشکر. تعداد کاربر به این استان اضافه شدند.","updatetableinfo"=>$inout_respons_success_array));
						return $respons_success_array;

};

if(isset($_FILES["myfile"]))
{
	if ($_FILES["myfile"]["error"] > 0)
	{
	  echo "Error: " . $_FILES["file"]["error"] . "<br>";
	}
	else
	{
		$filename = $_FILES["myfile"]["name"];
    	if (move_uploaded_file($_FILES["myfile"]["tmp_name"],$output_dir. $filename)) {
    		$address = "/uploadxls/".$filename; 
    		//if (chmod($address, 0755)) {
    		
    		
    		include 'PHPExcel/IOFactory.php';

			$respons_error_array = Array("0"=>Array("status"=>"fulse"));

			 $inputFileName = "./uploadxls/".$filename;

			 $objPHPExcel = PHPExcel_IOFactory::load($inputFileName);

			 $sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,false);
			   					
			//------------------------------
			 $id = 0;
			 $output_user_array = Array();

			foreach ($sheetData as $key => $value) {
				    $user_array = create_user_array($value[0],$value[1],$value[2],$value[3]);
				    $explode = explode("," , $user_array[0]);
	 	 			$output_ou =  $explode[0] . "," . $explode[1];

			 if (user_add($user_array[0],$user_array[1])) {
			 	$output_user_array[$id] = Array("ou"=>$output_ou,"name"=>$value[0],"pass"=>$value[1],"email"=>$value[2]);
			 	$id++;
			 	continue;
			 }else{
			    echo json_encode($respons_error_array);
				die();
			 };
			};

echo json_encode(get_response_success($output_user_array)); 
    	
		//}else echo "cheraaaa";
    	}else echo "noooooo";
    	
    
   	 //echo "Uploaded File :".$_FILES["myfile"]["name"];
	};

};
?>

