<?php

include 'config.php';

session_start();
if ($_SESSION["status"]=="authed") {
	
echo '

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Ldap-Panel</title>
	<meta name="viewport" content="width=device-width" />
	<!--[if lt IE 9]><script src="./assets/html5.js"></script><![endif]-->
	
	<meta name="robots" content="index,follow" />
	<link rel="stylesheet" href="./assets/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="./assets/dist/themes/default/style.min.css" />
	<link rel="stylesheet" href="./assets/docs.css" />
	<link rel="stylesheet" href="./assets/uikit-.1.0.1.min.css" />
	<link rel="stylesheet" href="./assets/cust.css" />
	<!--[if lt IE 9]><script src="./assets/respond.js"></script><![endif]-->
	
	<link rel="icon" href="./assets/favicon.ico" type="image/x-icon" />
	<link rel="apple-touch-icon-precomposed" href="./assets/apple-touch-icon-precomposed.png" />
	<script>window.$q=[];window.$=window.jQuery=function(a){window.$q.push(a);};</script>
</head>
<body>

					<div id="page-content">
						<a class="btn btn-danger btn-large btn-exit" href="logout.php">خروج از سیستم</a>
					<div id="jstree2" class="demo" style="margin-top:2em;"></div>
					<div id="tree-node-content"><table class="tree-node-content-table"><tr><th>Mobile Number</th><th>Email Address</th><th>Full Name</th><th>Action</th></tr></table></div>
						</div>
						<script id="content-template" type="text/content-tmpl">
						   <tr>
						   		<td>{{id}}</td>
						   		<td>{{mobile}}</td>
						   		<td>{{address}}</td>
						   		<td>{{name}}</td>
						   		<td><a data-ou={{ou}} class="modify-btn"></a><a data-ou={{ou}} class="delete-btn"></a></td>
						   </tr>
						</script>
						<script id="content-template-helper" type="text/content-tmpl">
						   <tr>
						   		<td>{{id}}</td>
						   		<td>{{mobile}}</td>
						   		<td>{{address}}</td>
						   		<td>{{name}}</td>
						   		<td><a data-ou={{ou}} class="modify-btn-helper"></a><a data-ou={{ou}} class="delete-btn-helper"></a></td>
						   </tr>
						</script>
						<script>
						$(function () {
							$("#jstree2").jstree({"core" : {"data" : {"url" : "array-conversion.php"}}});
							$("#jstree2").on("changed.jstree", function (e, data) {
    										var i, j,n = [], p = [];
    										 	for(i = 0, j = data.selected.length; i < j; i++) {
      												n.push(data.instance.get_node(data.selected[i]).text);
      												p.push(data.instance.get_parent(data.selected[i]));
    												}
    												if (n == "node1") {
    													$("#tree-node-content").html("<h1 style=text-align:center;color:white;margin-top:80px;>لطفأ یکی از استان ها را از درخت سمت راست انتخاب کنید.</h1>").fadeIn("300");
    												}else{
    													get_node_content("ou="+n.toString());
    												};
  						}).jstree();
							temp = $.trim($("#content-template").html());
							temp_helper = $.trim($("#content-template-helper").html());
							var globalindex="0";
							var globalfunctionvar = "0";
							var globalqueuekey = "0";
        					var globalfrag = "";
        					var frag = "";
							var globalthat;
						    var globalparent;
						    var globalou;
						    var globalounode;
						     $(".yes-add-user").click(function(){
						     	var name = $("#name").val();
						     	var mobile = $("#mobile").val();
						     	var email = $("#address").val();
						     	var pass = $("#pass").val();
						     	user_add(globalounode,name,mobile,email,pass);
						     });
						     $(".yes-modify").click(function(){
						     	var name = $("#name-id").val();
						     	var email = $("#address-id").val();
						     	var pass = $("#pass-id").val();
						     	user_modify(globalou,name,email,pass);
						     });
						     $(".yes-delete").click(function(){
						     	user_delete(globalou);
						     });
						$("div#background , div#background-temp , a.close , button.no , button.no-temp" ).on("click" , function(){
                            closepopup();
                        });
						$(".no-alert , .close-alert" ).on("click" , function(){
							$("div.alertbox , div.empty-alert , div.phone-alert , div.email-alert").fadeOut();
						});
						$("#mobile").focus(function() {
							var mobilegrandpa = $(this).parent().parent();
							mobilegrandpa.removeClass("error").removeClass("success").removeClass(".mobile-error-cause");
								if (!$("#address").parent().parent().hasClass("address-error-cause")) {
								$(".yes-add-user").removeAttr("disabled");
								};
							$("#mobile-error-message").fadeOut();
						});
						$("#address").focus(function() {
							var addressgrandpa = $(this).parent().parent();
							addressgrandpa.removeClass("error").removeClass("success").removeClass(".address-error-cause");
								if (!$("#mobile").parent().parent().hasClass("mobile-error-cause")) {
								$(".yes-add-user").removeAttr("disabled");
								};
							$("#address-error-message").fadeOut();
						});
						 $("#mobile , #address").on("change",(function (e) {
							  var id = e.target.id;
							   check_input_unique($("#"+id).val(),id);
						}));
						 function input_handler(condition,determiner,value){
						 if(condition&&(handle_determiner(determiner,value))){
						  	$("#"+determiner).parent().parent().addClass("success");
						  	$(".yes-add-user").removeAttr("disabled");
						  }else{
						  	$("#"+determiner+"-error-message").fadeIn().parent().parent().addClass("error").addClass(determiner+"-error-cause");
						  	$(".yes-add-user").attr("disabled","");
						  };	
						 };
						 function handle_determiner(determiner,value){
						 	if (determiner=="address") {
						 		return validateEmail(value+"@test.ir");
						 	};
						 	if (determiner=="mobile") {
						 		return validatePhone(value);
						 	};
						 };
						 function check_input_unique(arg , argtype){
						 	var globalinputcondition ;
						 	 $.post("check_input.php",
  										{el:arg,
  									 eltype:argtype},
  								function(data){
  									 $.each(data , function(index , object){
                         				if (object.status=="true"){
                         					input_handler(true,argtype,arg);
                         					console.log("1");
                         					return true;
                         				}else{
                         					input_handler(false,argtype,arg);
                         					return false;
                         				}
                         			})
        							});//.queue(function(){return globalinputcondition;});
						 };
                        function get_node_content(our_ou){
  									if ($("#tree-node-form").length) {
  										$("#tree-node-form").remove();
  									};
  									var buttons = $("");
  									var table = $("<button id=add-user type=button data-ou="+our_ou+" class=btn-cust>اضافه کردن کاربر</button><button id=add-user-excel type=button data-ou="+our_ou+" class=btn-cust>ورودی اکسل</button><table id=tree-node-content-table border=1><tr><th>شماره</th><th>شماره موبایل</th><th>آدرس ایمیل</th><th>نام کامل</th><th>عملیات</th></tr></table>");
								$.post("node-users.php",
  										{ou:our_ou},
  								function(data){
		        					frag=+"";
		        					$("div#tree-node-content").hide();
  									$("div#tree-node-content").html(table);
  									$.each(data , function(index , object){
  										globalindex = index;
						                frag = temp.replace(/{{id}}/ig , index)
						                			.replace(/{{mobile}}/ig , object.mobile)
						                			.replace(/{{address}}/ig , object.address)
						                			.replace(/{{name}}/ig , object.name)
						                            .replace(/{{ou}}/ig , object.ou);
						                 $("table#tree-node-content-table").append(frag);
            							});
  									$("table#tree-node-content-table , div#tree-node-content").fadeIn("200");
  									$(".btn-cust").addClass("btn btn-info btn-large");
        						run();
        							});
							};
                        function run(){
                        	if (globalfunctionvar=="0") {
                        globalfunctionvar =function(){
                        	 $("button#add-user-excel").on("click" , function(){
                        	 	empty_add_user_excel_form();
								var that1 = $(this);
								var ou = that1.data("ou");
										globalounode = ou;
								$("#ouform").val(ou);
								var form00 = $("div.upload-file");
								showpopup(form00);
								});
                        	 $("button#add-user").on("click" , function(){
                        	 	empty_add_user_form();
								var that1 = $(this);
								var ou = that1.data("ou");
										globalounode = ou;
								var form0 = $("div.add-user-form");
								showpopup(form0);
								});
						     $("a.delete-btn").on("click" , function(){    
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
								var form = $("div.delete");
								showpopup(form);
								});
						     $("a.modify-btn").on("click" , function(){
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
						                set_user_modify_form_data(ou);
								var form1 = $("div.add");
								showpopup(form1);
							});
						 };
						};
						execute(globalfunctionvar);
						 };
						 function execute(fn){
						 	fn();
						 };
						 function helper_run(){
						 	 $("a.delete-btn-helper").on("click" , function(){    
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
								var form = $("div.delete");
								showpopup(form);
								});
						     $("a.modify-btn-helper").on("click" , function(){
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
						                set_user_modify_form_data(ou);
								var form1 = $("div.add");
								showpopup(form1);
							});
						 };
                        function get_parent_name(id_string){
								var parents = $("#"+id_string);
								var parentsname =  parents.find("a.jstree-anchor").first().text();
						};
                        function closepopup(){
                        $("div.custom , div.alertbox , div.empty-alert , div.phone-alert , div.email-alert").fadeOut("400" , function(){
                            $("div#background , div#background-temp").fadeOut(500);
                            });
                        	return true;
                        };
                        function showpopup(popup,temp){
                        	var srch = screen.height;
								var srcw = screen.width;
								Ph = ((srch/2)-(popup.outerHeight()/2))-70;
								Pw = (srcw/2)-(popup.outerWidth()/2);
								if (temp=="temp") {$("div#background-temp").fadeIn("500");}
								else{$("div#background").fadeIn("500");};
									popup.delay(500).animate({
										"top" : Ph ,
										"left" : Pw
									} , 0).css("position" , "fixed").fadeIn(250);
                        };
                        function showalertpopup(popup,emptystatus,emailstatus,mobilestatus){
                        	var srch = screen.height;
								var srcw = screen.width;
								Ph = ((srch/2)-(popup.outerHeight()/2))-70;
								Pw = (srcw/2)-(popup.outerWidth()/2);
									popup.delay(500).animate({
										"top" : Ph ,
										"left" : Pw
									} , 0).css("position" , "fixed").fadeIn(250);
									if (emptystatus) {
										$(".empty-alert").fadeIn(300);
									};
									if (emailstatus) {
										$(".email-alert").fadeIn(350);
									};
									if (mobilestatus) {
										$(".phone-alert").fadeIn(400);
									};
                        };
                        function user_add(parentou , name , mobile , email , pass){
                        	var usable_email = email + "@fci.co.ir";
                        	if (parentou=="ou=tcz.ir") {usable_email = email + "@tcz.ir";};
                        	if (check_add_user_data(name,mobile,usable_email,pass)) {
                        	$.post("user_add.php",
                        		{parentou : parentou 
                        		   , name : name 
                        		 , mobile : mobile
                        		  , email : usable_email 
                        		   , pass : pass}
                        		,function(data , status){
                        			$.each(data , function(index , object){
                        				if (object.status=="true"){
                        					succeed_popup();
                        					update_table(object.ou,mobile,usable_email,name);
                        				}else{
                        					alert("خطایی رخ داده است.");
                        				};	
                        			});
                        		});
                        	};
                        };
                        function user_delete(ou){
                        	$.post("user_delete.php",
                        		{ou:ou}
                        		,function(data , status){
                        			$.each(data , function(index , object){
                        				if (object.status=="true"){
                        					succeed_popup();
                        					globalparent.remove();
                        				}else{
                        					alert("خطایی رخ داده است.");
                        				};	
                        			});
                        		});
                        };
                        function user_modify(ou , name , email , pass){
                        	if(check_modify_data(name,email,pass)){
                        	$.post("user_modify.php",
                        		{ou:ou,
                        		 name  : name,
                        		 email : email,
                        		 pass  : pass}
                        		,function(data){
                        			$.each(data , function(index , object){
                        				if (object.status=="true"){
                        					succeed_popup();
                        					update_user_info(ou,name,email);
                        				}else{
                        					alert("خطایی رخ داده است.");
                        				};
                        			});
                        		});
                        	};
                        };
                        function set_user_modify_form_data(ou){
							$.post("user_modify_form_data.php",
                        		{ou:ou}
                        		,function(data){
                        			$.each(data , function(index , object){
                        				$("#name-id").val(object.name);
                        				$("#address-id").val(object.address);
                        				$("#pass-id").val(object.pass);
                        			});
                        		});
                        };
                        function update_user_info(ou , name , email){
                        	globalparent.children("td:nth-child(4)").text(name);
                        	globalparent.children("td:nth-child(3)").text(email);
                        };
                        function update_table(ou , mobile , email , name){
                        	frag_helper = temp_helper.replace(/{{id}}/ig , globalindex+1)
						                			.replace(/{{mobile}}/ig , mobile)
						                			.replace(/{{address}}/ig , email)
						                			.replace(/{{name}}/ig , name)
						                            .replace(/{{ou}}/ig , ou);
						                 $("table#tree-node-content-table").append(frag_helper);
						                 helper_run();
                        };
                        function succeed_popup(){
                        	var succeed = $("div.succedens");
                        	showpopup(succeed,"temp");
                        };
                        function empty_add_user_form(){
                        		$(".control-group").removeClass("error").removeClass("success");
                        		$(".help-inline").hide();
								$("#name").val("");
						     	$("#mobile").val("");
						     	$("#address").val("");
						     	$("#pass").val("");
                        };
                        function empty_add_user_excel_form(){
								$("#fileform").val("");
								$(".bar").css("width","0");
								$("#message").html("");
								$("#percent").text("0%");
                        };
                        function check_modify_data(name,address,pass){
                        	var modify_mobile_status = false;
                        	var emptystatus = false;
                        	var emailstatus = false;
                        	var passstatus = false;
                        	var errorpopup = $("div.alertbox");
                        	if ((name.length==0)||(address.length==0)||(pass.length==0)) {
                        		emptystatus = true;
                        	};
                        	if (!validateEmail(address)) {
                        		emailstatus = true;
                        	};
                        	if (emptystatus||emailstatus||passstatus) {
                        		showalertpopup(errorpopup,emptystatus,emailstatus,modify_mobile_status);
                        		return false;
                        	}else{return true;};
                        };
                        function check_add_user_data(name,mobile,address,pass){
                        	var emptystatus = false;
                        	var emailstatus = false;
                        	var mobilestatus = false;
                        	var passstatus = false;
                        	var errorpopup = $("div.alertbox");
                        	if ((name.length=0)||(mobile.length==0)||(address.length==0)||(pass.length==0)) {
                        		emptystatus = true;
                        	};
                        	if (!validatePhone(mobile)) {
                        		mobilestatus = true;
                        	};
                        	if (!validateEmail(address)) {
                        		emailstatus = true;
                        	};
                        	if (emptystatus||mobilestatus||emailstatus||passstatus) {
                        		showalertpopup(errorpopup,emptystatus,emailstatus,mobilestatus);
                        		return false;
                        	}else{return true;};
                        };
                        function validatePhone(phone) { 
					    var rev = /^09\d{2}\s*?\d{3}\s*?\d{4}$/;
					    return rev.test(phone);
						};
						function validateEmail(email) { 
					    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
					    return re.test(email);
						};
						});
					</script>
					</div>
					<div id="background"></div>
					<div id="background-temp"></div>
					 <div class="hero-unit custom alertbox">
			            <a class="close-alert">&times;</a>
			            <h3>هشدار!</h3>
			            <div class="alert alert-error empty-alert">
					    <strong>اخطار!</strong> لطفأ هیچ فیلدی را خالی نگذارید.
					    </div>
					    <div class="alert alert-error email-alert">
					    <strong>ایمیل وارد شده نامعتبر است.</strong>لطفأ برای آدرس دهی ایمیل از الگوی phonenumber@yourdomain.ir استفاده نمایید.
					    </div>
					    <div class="alert alert-error phone-alert">
					    <strong>شماره تلفن وارد شده نامعتبر است.</strong>لطفأ شماره تلفنی شروع شونده با الگوی شماره تلفن های اپراتور های داخل کشور وارد مایید.
					    </div>
			            <p>
			            <button class="btn btn-primary no-alert">
			                    بله
			            </button>
			            </p>
			        </div>
					<div class="hero-unit custom customize add-user-form">
       				     <a class="close">&times;</a>
            			<h3>اضافه نمودن کاربر:</h3>
			             <p>لطفأ مشخصات کاربر را با دقت وارد کنید و پس از پر کردن تمام فیلدها بر روی دکمه ثبت کلیک کنید.</p> 
             			 <p>نام کامل:</p> 
             			 <div class="control-group">
				            <div class="controls">
				              <input type="text" id="name" name="name" class="modify input-xlarge" value="" />
				            </div>
				          </div>
            			 <p>شماره موبایل:</p> 
            			 <div class="control-group">
				            <div class="controls">
            			 <input type="text" id="mobile" name="mobile" class="modify input-xlarge" value="" />
            			 <span id="mobile-error-message" class="help-inline">شماره موبایل وارد شده نامعتبر یا تکراری است.</span>
            			 	</div>
				          </div>
            			 <p>شناسه حرفی:</p> 
            			 <div class="control-group">
				            <div class="controls">
            			 <input type="text" id="address" name="email" class="modify input-xlarge" value="" />
            			 <span id="address-error-message" class="help-inline">آدرس ایمیل وارد شده نامعتبر یا تکراری است.</span>
            			 	</div>
				          </div>
            			 <p>رمز عبور:</p> 
            			 <div class="control-group">
				            <div class="controls">
            			 <input type="password" id="pass" name="pass" class="modify input-xlarge" value="" />
            			 	</div>
				          </div>
            			 <p>
                		 <button class="btn btn-primary yes-add-user" type="submit" value="submit">
							ثبت شود
                		 </button>
                		 <button class="btn btn-primary no">
          				  لغو
                		 </button>
            			 </p>
        			</div>
					<div class="hero-unit custom add">
       				     <a class="close">&times;</a>
            			<h3>ویرایش کاربر:</h3>
			             <p>لطفأ تغییرات مد نظر را اعمال نموده و برای ثبت دکمه «ویرایش شود» را کلیک کنید.</p> 
             			 <p>نام و نام خانوادگی:</p> 
            			 <input type="text" id="name-id" name="name" class="modify" value="" />
            			 <p>آدرس ایمیل:</p> 
            			 <input type="text" id="address-id" name="address" class="modify" value="" />
            			 <p>رمز عبور:</p> 
            			 <input type="password" id="pass-id" name="pass" class="modify" value="" />
            			 <p>
                		 <button class="btn btn-primary yes-modify" type="submit" value="submit">
							ویرایش شود
                		 </button>
                		 <button class="btn btn-primary no">
          				  لغو
                		 </button>
            			 </p>
        			</div>
        			 <div class="hero-unit custom delete delebaba">
			            <a class="close">&times;</a>
			            <h3>اخطار!</h3>
			            <p>آیا برای حذف این کاربر مطمئن هستید؟</p> 
			            <p>
			            <button class="btn btn-primary yes-delete" type="submit" value="submit">
			                    بلی حذف شود
			            </button>
			            <button class="btn btn-primary no">
			                    لغو
			            </button>
			            </p>
			        </div>
			        <div class="hero-unit custom succedens">
			            <a class="close">&times;</a>
			            <h3>پیام:</h3>
			            <p>رکورد شما با موفقیت ثبت شد.</p> 
			            <p>
			            <button class="btn btn-primary no-temp">
			                    بله
			            </button>
			            </p>
			        </div>
			        <div class="hero-unit custom upload-file">
       				    <a class="close">&times;</a>
            			<h3>اضافه نمودن کاربر با استفاده از فایل اکسل:</h3>
            			<div class="alert-cust alert-info">
					    <strong>توجه!</strong> لطفأ فایل بارگذاری شده حتمأ از نوع اکسل و با پسوند xls باشد. و حتمأ کاربر تکراری وجود نداشته باشد.
					    </div>
             			<p>آپلود فایل:</p> 
             			<form id="myForm" action="xls_upload.php" method="post" enctype="multipart/form-data">
            			<input id="fileform" type="file" name="myfile" class=""/>
            			<input id="ouform" type="text" name="myou" style="display:none;" class=""/>
            			<div id="progress" class="progress progress-striped active">
						<div id="bar" class="bar"></div>
						<div id="percent">0%</div >
						</div>
						<br/>						    
						<div id="message"></div>
                		<button class="btn btn-primary yes-upload-file" type="submit" value="submit">
							ارسال شود
                		</button>
                		<button type="button" class="btn btn-primary no">
          				  لغو
                		</button>
                		</form>
        			</div>

		<script src="./assets/jquery-1.10.2.min.js"></script>
		<script src="./assets/jquery.tmpl.min.js"></script>
	<script src="./assets/jquery.address-1.6.js"></script>
	<script src="./assets/vakata.js"></script>
	<script src="./assets/dist/jstree.min.js"></script>
	<script src="./assets/docs.js"></script>
	<script src="js/jquery.form.js"></script>
	<script>
	function helper_run(){
						 	 $("a.delete-btn-helper").on("click" , function(){    
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
								var form = $("div.delete");
								showpopup(form);
								});
						     $("a.modify-btn-helper").on("click" , function(){
								var that1 = $(this);
								var ou = that1.data("ou");
										globalou = ou;
						                globalthat = that1;
						                globalparent = that1.parent().parent();
						                set_user_modify_form_data(ou);
								var form1 = $("div.add");
								showpopup(form1);
							});
						 };
	function update_table(ou , name  , email , mobile){
		var globalindex=parseInt($("table#tree-node-content-table tr:last-child td:first-child").text());
                        	frag = temp.replace(/{{id}}/ig , globalindex+1)
						                			.replace(/{{mobile}}/ig , mobile)
						                			.replace(/{{address}}/ig , email)
						                			.replace(/{{name}}/ig , name)
						                            .replace(/{{ou}}/ig , ou);
						                 $("table#tree-node-content-table").append(frag);
						                 globalindex++;
							helper_run();
                        };
		$(document).ready(function()
		{

			var options = { 
		    beforeSend: function() 
		    {
		    	$("#progress").show();
		    	$("#bar").width("%");
		    	$("#message").html("");
				$("#percent").html("0%");
		    },
		    uploadProgress: function(event, position, total, percentComplete) 
		    {
		    	$("#bar").width(percentComplete+"%");
		    	$("#percent").html(percentComplete+"%");
		    },
		    success: function() 
		    {
		        $("#bar").width("100%");
		    	$("#percent").html("100%");
		    },
			complete: function(response) 
			{
				$.each(response.responseJSON , function(index , object){
					$("#message").html("<font color=green>"+object.responsestatustext+"</font>");
					$.each(object.updatetableinfo , function(i,obj){
					update_table(obj.ou,obj.name,obj.email,obj.pass);
					});
				});
			},
			error: function()
			{
				$("#message").html("<font color=red> ERROR: unable to upload files</font>");
			}
		     
		}; 

		     $("#myForm").ajaxForm(options);

		});

</script>
	<script>$.each($q,function(i,f){$(f)});$q=null;</script>
</body>
</html>';
}else{
	$redirect_address = "http://".get_project_url().get_panel_page_location();
	header('Location:'.$redirect_address);
};
?>
