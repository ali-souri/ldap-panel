<?php

include 'config.php';

$projecturl = get_project_url(); 						// "192.168.1.202"
	$ldapconnectaddress = get_ldap_connect_address();		// "127.0.0.1"
	$ldapconnectport = get_ldap_connect_port();				// 389
	$adminbindrdn = get_admin_bind_rdn();					// cn=admin,dc=elenoon,dc=ir
	$adminbindpass = get_admin_bind_pass();					// ahmad@91
	$mainserverrdn = get_main_server_rdn();					// dc=elenoon,dc=ir
	$customadmindn = get_custom_admin_dn();					// cn=customadmin
	$customadminrdn = get_custom_admin_rdn();				// cn=customadmin,dc=elenoon,dc=ir
	$customadminusername = get_custom_admin_username();		// customadmin
	$customadminpass = get_custom_admin_pass();				// abas?1371
	$bindadmindn = get_bind_admin_dn();						// cn=admin
	$bindadminrdn = get_bind_admin_rdn();					// cn=admin,dc=elenoon,dc=ir
	$indexpagelocation = get_index_page_location();			// /ldappanel/index.php
	$panelpagelocation = get_panel_page_location();			// /ldappanel/panel.php 
	$logoutpagelocation = get_logout_page_location();		// /ldappanel/logout.php
	$node1rdn = get_node1_rdn();							// ou=node1,dc=elenoon,dc=ir
	$node1usablerdn = get_node1_usable_rdn();				//,ou=node1,dc=elenoon,dc=ir
	$zarafauserserver = get_zarafauserserver();				// 192.168.0.22
	$oustar = get_ou_star(); 								// ou=*


error_reporting(E_ALL);
set_time_limit(0);

date_default_timezone_set('Europe/London');

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

<title>PHPExcel Reader Example #01</title>

</head>
<body>

<h1>PHPExcel Reader Example #01</h1>
<h2>Simple File Reader using PHPExcel_IOFactory::load()</h2>
<?php

/** Include path **/
set_include_path(get_include_path() . PATH_SEPARATOR . './Classes/');

/** PHPExcel_IOFactory */
include 'PHPExcel/IOFactory.php';


$inputFileName = './uploadxls/test.xls';
echo 'Loading file ',pathinfo($inputFileName,PATHINFO_BASENAME),' using IOFactory to identify the format<br />';
$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);


echo '<hr />';

//$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,false);
   

   echo "<div style='white-space:pre;'>";
var_dump($sheetData);
	 echo "</div>";



?>
<body>
</html>