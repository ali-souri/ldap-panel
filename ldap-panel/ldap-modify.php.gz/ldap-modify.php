<?php

	$modify_array = Array();
	//$modify_array = Array ( "givenname" => "ali" ,"zarafaquotawarn" => 1 ,"zarafaquotasoft" => 1 ,"cn" => "souri" ,"zarafaquotahard" => 100 ,"uid" => "alisouri" ,"mail" => "alisouri@fci.co.ir" ,"zarafaquotaoverride" => 12 ,"userpassword" => 123 ,"telephonenumber" => "09127975061" ,"mobile" => "09127975061" ,"sn" => "souri" );
	 $rdn = "";
	foreach ($_REQUEST as $key => $value) {
		if ($key=="dn") {
			$rdn = $value;
		}elseif ($key!="objectclass") {
		  $modify_array[$key] = $value;
		}}
//	$rdn = $_REQUEST["rdn"];

//header('Content-type: application/json');

if ($rdn) {

	$ds=ldap_connect( "127.0.0.1", 389 );
if ($ds) {
	$r=ldap_bind($ds, "cn=customadmin,dc=elenoon,dc=ir", "abas?1371");
	if ($r) {
	$md_st = ldap_modify($ds , $rdn , $modify_array);//($ds, $dn, $userdata);
	//$sr=ldap_search($ds, "dc=elenoon,dc=ir", $rdn);//objectClass=zarafa-company
	if ($md_st) {
	//$info = ldap_get_entries($ds, $sr);

	echo "nice";
	
	//$json_last_array = Array();
	

	
	// echo json_encode($json_last_array);
	}else{
		echo "ajabaaaa";
		echo $modify_array;
    echo "<div style='white-space:pre;'>";
		 print_r($modify_array);
    		echo "</div>";
	}
	}



	
	ldap_close($ds);
} else {
	echo "<h4>Unable to connect to LDAP server</h4>";
}
}
?>