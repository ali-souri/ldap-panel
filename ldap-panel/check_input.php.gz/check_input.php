<?php

include 'config.php';

	$projecturl = get_project_url();
	$ldapconnectaddress = get_ldap_connect_address();
	$ldapconnectport = get_ldap_connect_port();
	$adminbindrdn = get_admin_bind_rdn();
	$adminbindpass = get_admin_bind_pass();
	$mainserverrdn = get_main_server_rdn();
	$customadmindn = get_custom_admin_dn();
	$customadminrdn = get_custom_admin_rdn();
	$customadminusername = get_custom_admin_username();
	$customadminpass = get_custom_admin_pass();
	$bindadmindn = get_bind_admin_dn();
	$bindadminrdn = get_bind_admin_rdn();
	$indexpagelocation = get_index_page_location();
	$panelpagelocation = get_panel_page_location();
	$logoutpagelocation = get_logout_page_location();	
	$node1rdn = get_node1_rdn();
	$node1usablerdn = get_node1_usable_rdn();
	$zarafauserserver = get_zarafauserserver();
	$oustar = get_ou_star(); 



header('Content-type: application/json');

//$father = $_REQUEST['elparent'];
$element = $_REQUEST['el'];
$element_type = $_REQUEST['eltype'];
//echo $element." ".$element_type;
$respons_success_array = Array("0"=>Array("status"=>"true"));
$respons_error_array = Array("0"=>Array("status"=>"fulse"));

	function get_search_variable($our_element){
		if($our_element=="address"){
			return "mail";
		}elseif ($our_element=="mobile") {
			return "mobile";
		};
	};

$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );
ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        ldap_set_option($ds, LDAP_OPT_REFERRALS,0);

if ($ds) {
	
$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);
	if ($r) {
	
	$sr=ldap_search($ds, $node1rdn , get_search_variable($element_type)."=".$element);
								//"mobile=09127975061");//
	if ($sr) {
		
	
	$info = ldap_get_entries($ds, $sr);

	if ($info[count]) {
		echo json_encode($respons_error_array);
	}else{
		echo json_encode($respons_success_array);	
	};
	 // echo "<br/>";
	 // echo "<div style='white-space:pre;'>";
	 // print_r($info);
	 // echo "</div>";
	 // echo "<div style='white-space:pre;'>";
	 // echo json_encode($info);
	 // echo "</div>";
 };
};
	ldap_close($ds);
} else {
	echo "<h4>Unable to connect to LDAP server</h4>";
}
?>
