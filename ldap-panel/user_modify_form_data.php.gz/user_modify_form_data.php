<?php

include 'config.php';

$projecturl = get_project_url(); 						// "192.168.1.202"
	$ldapconnectaddress = get_ldap_connect_address();		// "127.0.0.1"
	$ldapconnectport = get_ldap_connect_port();				// 389
	$adminbindrdn = get_admin_bind_rdn();					// cn=admin,dc=elenoon,dc=ir
	$adminbindpass = get_admin_bind_pass();					// ahmad@91
	$mainserverrdn = get_main_server_rdn();					// dc=elenoon,dc=ir
	$customadmindn = get_custom_admin_dn();					// cn=customadmin
	$customadminrdn = get_custom_admin_rdn();				// cn=customadmin,dc=elenoon,dc=ir
	$customadminusername = get_custom_admin_username();		// customadmin
	$customadminpass = get_custom_admin_pass();				// abas?1371
	$bindadmindn = get_bind_admin_dn();						// cn=admin
	$bindadminrdn = get_bind_admin_rdn();					// cn=admin,dc=elenoon,dc=ir
	$indexpagelocation = get_index_page_location();			// /ldappanel/index.php
	$panelpagelocation = get_panel_page_location();			// /ldappanel/panel.php 
	$logoutpagelocation = get_logout_page_location();		// /ldappanel/logout.php
	$node1rdn = get_node1_rdn();							// ou=node1,dc=elenoon,dc=ir
	$node1usablerdn = get_node1_usable_rdn();				//,ou=node1,dc=elenoon,dc=ir
	$zarafauserserver = get_zarafauserserver();				// 192.168.0.22
	$oustar = get_ou_star(); 								// ou=*


	$ou = $_REQUEST['ou'];

header('Content-type: application/json');


	$explode_ou = explode("," , $ou);

	$uid = $explode_ou[0];

	$parent_ou = $explode_ou[1];

	$search_ou = $parent_ou . $node1usablerdn;

	$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );
ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        ldap_set_option($ds, LDAP_OPT_REFERRALS,0);

if ($ds) {

	$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);
	if ($r) {
	 
	
	$sr=ldap_search($ds, $search_ou , $uid);

	if ($sr) {
	
	$info = ldap_get_entries($ds, $sr);

	 $id = 0;
	 $json_last_array = Array();


	 foreach ($info as $key => $value) {
	 	 if ($key!=="count") {
	 		$helper_array = Array( "name" => $info[$id]["cn"][0] , "address" => $info[$id]["mail"][0] , "pass" => $info[$id]["userpassword"][0]);
 	 			$json_last_array[$id] = $helper_array;
 	 			$id++;
	 	 	}
	 	}
	 
	echo json_encode($json_last_array);

	ldap_close($ds);
}
}
} else {
	echo "<h4>Unable to connect to LDAP server</h4>";
}


	?>

