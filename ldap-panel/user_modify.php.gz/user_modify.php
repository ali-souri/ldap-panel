<?php

include 'config.php';

	$projecturl = get_project_url();
	$ldapconnectaddress = get_ldap_connect_address();
	$ldapconnectport = get_ldap_connect_port();
	$adminbindrdn = get_admin_bind_rdn();
	$adminbindpass = get_admin_bind_pass();
	$mainserverrdn = get_main_server_rdn();
	$customadmindn = get_custom_admin_dn();
	$customadminrdn = get_custom_admin_rdn();
	$customadminusername = get_custom_admin_username();
	$customadminpass = get_custom_admin_pass();
	$bindadmindn = get_bind_admin_dn();
	$bindadminrdn = get_bind_admin_rdn();
	$indexpagelocation = get_index_page_location();
	$panelpagelocation = get_panel_page_location();
	$logoutpagelocation = get_logout_page_location();	
	$node1rdn = get_node1_rdn();
	$node1usablerdn = get_node1_usable_rdn();
	$zarafauserserver = get_zarafauserserver();
	$oustar = get_ou_star(); 


header('Content-type: application/json');
	

$ou = $_REQUEST['ou'];
$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$pass = $_REQUEST['pass'];

$entry_array = Array("cn" => Array( "0" => $name ) , "mail" => Array( "0" => $email ) , "userpassword" => Array( "0" => $pass ));

$dn = $ou . $node1usablerdn;
$respons_success_array = Array("0"=>Array("status"=>"true"));
$respons_error_array = Array("0"=>Array("status"=>"fulse"));


$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );
ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        ldap_set_option($ds, LDAP_OPT_REFERRALS,0);

if ($ds) {
	$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);
	if ($r) {
	 
	$sr=ldap_modify($ds , $dn , $entry_array);
	if ($sr) {
	
	// [0] => Array ( [cn] => Array ( [count] => 1 [0] => first ) [0] => cn [gidnumber] => Array ( [count] => 1 [0] => 100009 ) [1] => gidnumber [homedirectory] => Array ( [count] => 1 [0] => /home/9809121452949100009 ) [2] => homedirectory [mail] => Array ( [count] => 1 [0] => eghbal@fci.co.ir ) [3] => mail [mobile] => Array ( [count] => 1 [0] => 09121452949 ) [4] => mobile [objectclass] => Array ( [count] => 4 [0] => posixAccount [1] => top [2] => zarafa-user [3] => inetOrgPerson ) [5] => objectclass [sn] => Array ( [count] => 1 [0] => 09121452949 ) [6] => sn [uid] => Array ( [count] => 1 [0] => eghbal@fci.co.ir ) [7] => uid [uidnumber] => Array ( [count] => 1 [0] => 9809121452949100009 ) [8] => uidnumber [userpassword] => Array ( [count] => 1 [0] => {ssha}AhyIomXd_T ) [9] => userpassword [zarafaaccount] => Array ( [count] => 1 [0] => 1 ) [10] => zarafaaccount [zarafaadmin] => Array ( [count] => 1 [0] => 0 ) [11] => zarafaadmin [zarafaalertsms] => Array ( [count] => 1 [0] => 1 ) [12] => zarafaalertsms [zarafaaliases] => Array ( [count] => 1 [0] => 09121452949@fci.co.ir ) [13] => zarafaaliases [zarafaconfirm] => Array ( [count] => 1 [0] => 1 ) [14] => zarafaconfirm [zarafaenabledfeatures] => Array ( [count] => 2 [0] => imap [1] => pop3 ) [15] => zarafaenabledfeatures [zarafahidden] => Array ( [count] => 1 [0] => 1 ) [16] => zarafahidden [zarafaquotahard] => Array ( [count] => 1 [0] => 1900 ) [17] => zarafaquotahard [zarafaquotaoverride] => Array ( [count] => 1 [0] => 1 ) [18] => zarafaquotaoverride [zarafaquotasoft] => Array ( [count] => 1 [0] => 1800 ) [19] => zarafaquotasoft [zarafaquotawarn] => Array ( [count] => 1 [0] => 1700 ) [20] => zarafaquotawarn [zarafasharedstoreonly] => Array ( [count] => 1 [0] => 0 ) [21] => zarafasharedstoreonly [zarafauserserver] => Array ( [count] => 1 [0] => 192.168.0.22 ) [22] => zarafauserserver [count] => 23 [dn] => uid=eghbal@fci.co.ir,ou=tehran,ou=node1,dc=elenoon,dc=ir )


echo json_encode($respons_success_array);

	
}else{
	echo json_encode($respons_error_array);
}
	ldap_close($ds);
}
} else {
	echo "<h4>Unable to connect to LDAP server</h4>";
}

?>
