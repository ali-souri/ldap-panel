<?php

include 'config.php';

	$projecturl = get_project_url();
	$ldapconnectaddress = get_ldap_connect_address();
	$ldapconnectport = get_ldap_connect_port();
	$adminbindrdn = get_admin_bind_rdn();
	$adminbindpass = get_admin_bind_pass();
	$mainserverrdn = get_main_server_rdn();
	$customadmindn = get_custom_admin_dn();
	$customadminrdn = get_custom_admin_rdn();
	$customadminusername = get_custom_admin_username();
	$customadminpass = get_custom_admin_pass();
	$bindadmindn = get_bind_admin_dn();
	$bindadminrdn = get_bind_admin_rdn();
	$indexpagelocation = get_index_page_location();
	$panelpagelocation = get_panel_page_location();
	$logoutpagelocation = get_logout_page_location();	
	$node1rdn = get_node1_rdn();
	$node1usablerdn = get_node1_usable_rdn();
	$zarafauserserver = get_zarafauserserver();
	$oustar = get_ou_star(); 


	session_start();
	session_destroy();
	$redirect_address = "http://".$projecturl.$indexpagelocation;
	header('Location: '.$redirect_address);
	//header('Location: /ldappanel/index.php');

?>