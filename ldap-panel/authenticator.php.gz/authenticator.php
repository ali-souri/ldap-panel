<?php
include 'config.php';

	$projecturl = get_project_url();
	$ldapconnectaddress = get_ldap_connect_address();
	$ldapconnectport = get_ldap_connect_port();
	$adminbindrdn = get_admin_bind_rdn();
	$adminbindpass = get_admin_bind_pass();
	$mainserverrdn = get_main_server_rdn();
	$customadmindn = get_custom_admin_dn();
	$customadminrdn = get_custom_admin_rdn();
	$customadminusername = get_custom_admin_username();
	$customadminpass = get_custom_admin_pass();
	$bindadmindn = get_bind_admin_dn();
	$bindadminrdn = get_bind_admin_rdn();
	$indexpagelocation = get_index_page_location();
	$panelpagelocation = get_panel_page_location();
	$logoutpagelocation = get_logout_page_location();	
	$node1rdn = get_node1_rdn();
	$node1usablerdn = get_node1_usable_rdn();
	$zarafauserserver = get_zarafauserserver();
	$oustar = get_ou_star(); 


	session_start();
	ob_start();
	$username = $_POST['user'];
	$password = $_POST['pass'];
	
echo $username . $password."--";
	$hashpass = md5($password);
	if ($username==$customadminusername) {
		
	
			//start_tls();
			$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );//or die("Could not connect to server");
			ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        ldap_set_option($ds, LDAP_OPT_REFERRALS,0);
			if ($ds) {
				//echo ldap_error();
				echo "--".$ds;
				echo "--".$adminbindrdn."--".$adminbindpass;
//				if(ldap_start_tls($ds))
//				{$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);}else{echo "na baradar";};
				$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);//echo ldap_error();
				if ($r) {
				echo "--".$r;
				echo "ahsant";
				$sr=ldap_search($ds, $mainserverrdn , $customadmindn);
					if ($sr) {
					$info = ldap_get_entries($ds, $sr);
					if (md5($info[0]["userpassword"][0])==$hashpass) {
						$authuser = "autheduser";
						$_SESSION["status"] = "authed";
						header('Location: http://'.$projecturl.$panelpagelocation);
						echo "salam";
					}else{echo "login failed";}
					}else{echo "ay baba";}
				}else{echo "eshtebah migi";};
				ldap_close($ds);
			} else {
				echo "<h4>Unable to connect to LDAP server</h4>";
			};
	}else{
		echo "no boy";
};
?>
