<?php

include 'config.php';

$projecturl = get_project_url(); 						// "192.168.1.202"
	$ldapconnectaddress = get_ldap_connect_address();		// "127.0.0.1"
	$ldapconnectport = get_ldap_connect_port();				// 389
	$adminbindrdn = get_admin_bind_rdn();					// cn=admin,dc=elenoon,dc=ir
	$adminbindpass = get_admin_bind_pass();					// ahmad@91
	$mainserverrdn = get_main_server_rdn();					// dc=elenoon,dc=ir
	$customadmindn = get_custom_admin_dn();					// cn=customadmin
	$customadminrdn = get_custom_admin_rdn();				// cn=customadmin,dc=elenoon,dc=ir
	$customadminusername = get_custom_admin_username();		// customadmin
	$customadminpass = get_custom_admin_pass();				// abas?1371
	$bindadmindn = get_bind_admin_dn();						// cn=admin
	$bindadminrdn = get_bind_admin_rdn();					// cn=admin,dc=elenoon,dc=ir
	$indexpagelocation = get_index_page_location();			// /ldappanel/index.php
	$panelpagelocation = get_panel_page_location();			// /ldappanel/panel.php 
	$logoutpagelocation = get_logout_page_location();		// /ldappanel/logout.php
	$node1rdn = get_node1_rdn();							// ou=node1,dc=elenoon,dc=ir
	$node1usablerdn = get_node1_usable_rdn();				//,ou=node1,dc=elenoon,dc=ir
	$zarafauserserver = get_zarafauserserver();				// 192.168.0.22
	$oustar = get_ou_star(); 								// ou=*

header('Content-type: application/json');
	
$parentou = $_REQUEST['parentou'];
$name = $_REQUEST['name'];
$mobile = $_REQUEST['mobile'];
$email = $_REQUEST['email'];
$pass = $_REQUEST['pass'];

$atdomain = "@fci.co.ir";

$dn = "uid=" . $mobile . $atdomain . "," . $parentou . $node1usablerdn;

$externalou = "uid=" . $mobile . $atdomain . "," . $parentou ;

$zarafauserserver = "192.168.0.22";

$gidnumber = 100009;

$homedirectory = "/home/98" . $mobile . $gidnumber;

$uidnumber = "98" . $mobile . $gidnumber;

$explode = explode("@", $email);
$sn = $explode[0];

$respons_success_array = Array("0"=>Array("status"=>"true","ou"=>$externalou));
$respons_error_array = Array("0"=>Array("status"=>"fulse"));

$entry_array = Array ( "cn" => $name  , "gidnumber" =>  $gidnumber , "homedirectory" => $homedirectory , "mail" => $email , "mobile" => $mobile ,"objectclass" => Array ("0" => "posixAccount" , "1" => "top" , "2" => "zarafa-user" , "3" => "inetOrgPerson")  , "sn" => $sn  , "uid"  => Array("0"=>$mobile.$atdomain , "1"=> $email)  , "uidnumber" => $uidnumber , "userpassword" =>  $pass , "zarafaaccount" =>  1 , "zarafaadmin" =>  0 , "zarafaalertsms" =>  1 , "zarafaaliases" =>  $mobile.$domain , "zarafaconfirm" =>  1 , "zarafaenabledfeatures" => Array (  "0" => "imap" , "1" => "pop3" ) , "zarafahidden" =>  1 , "zarafaquotahard" =>  1900 , "zarafaquotaoverride" => 1 , "zarafaquotasoft" => 1800 , "zarafaquotawarn" =>  1700 , "zarafasharedstoreonly" => 0 ,  "zarafauserserver" =>  $zarafauserserver) ;


$ds=ldap_connect( $ldapconnectaddress, $ldapconnectport );
ldap_set_option(NULL, LDAP_OPT_DEBUG_LEVEL, 7);
                        ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION,3);
                        ldap_set_option($ds, LDAP_OPT_REFERRALS,0);

if ($ds) {

	$r=ldap_bind($ds, $adminbindrdn , $adminbindpass);
	if ($r) {
	 
	$sr=ldap_add($ds , $dn , $entry_array);
	if ($sr) {

echo json_encode($respons_success_array);
	
}else{
	echo json_encode($respons_error_array);
}
	ldap_close($ds);
}
} else {
	echo "<h4>Unable to connect to LDAP server</h4>";
}

?>
